/* 
 * Created:   2022
 * Processor: PIC18F45K22
 * Compiler:  MPLAB XC8
 */

#include <xc.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "config.h"
#include "GLCD.h"
#define _XTAL_FREQ 8000000  

#define LOGIC_HIGH      1     //LOGIC high value  
#define LOGIC_LOW       0     //logic low value
#define CASCADE_DELAY   50
#define CHAR_WIDTH      5
#define CHAR_HEIGHT     8
#define MAX_SNAKE_SIZE	10

const char* nom1 = "Victor Cabre";
const char* nom2 = "Hugo Pelayo";
const char* LAB3 = "L4A GLCD";

int y_coordinate = 63;
int x_coordinate = 31;

enum Direction{UP, DOWN, LEFT, RIGHT};

char STATE = UP;

struct pos
{
   int y, x; 
};

int contador = 0;
struct pos tail[MAX_SNAKE_SIZE];

/*Write s to screen at page "page" starting from column y*/
void writeTxt(byte page, byte y, char * s) {
   int i=0;
   while (*s!='\n' && *s!='\0') 
   {
      putchGLCD(page, y+i, *(s++));
      i++;
   };
}	

void configPIC(void)
{
   ANSELA = 0b00000000; // Set pins for digital I/O
   ANSELB = 0b00000000; // Set pins for digital I/O                  
   ANSELC = 0b00000000; // Set pins for digital I/O                 
   ANSELD = 0b00000000; // Set pins for digital I/O
   ANSELE = 0b00000000; // Set pins for digital I/O   
   	
   TRISD = 0x00;        // Set all pins from PORTD as output
   TRISB = 0x00;        // Set all pins from PORTD as output   

   TRISAbits.RA0 = LOGIC_HIGH; // Set pin as input
   TRISAbits.RA1 = LOGIC_HIGH; // Set pin as input
   TRISAbits.RA2 = LOGIC_HIGH; // Set pin as input
   TRISAbits.RA3 = LOGIC_HIGH; // Set pin as input
   
   PORTD = 0x00;        //Clear LATD
   PORTB = 0x00;        //Clear LATB
}

//str is not empty
void present(const char* str, byte end_page, byte start_col)
{
    for (int i = 0; i < strlen(str); ++i)
    {
        char output = str[i];
        byte current_page = -1;
        byte col2;

        while (++current_page <= end_page && output != ' ')
        {
            putchGLCD(current_page, start_col, output);
            __delay_ms(CASCADE_DELAY);
            col2    =  start_col*CHAR_WIDTH-1;

            if (current_page != end_page) clearGLCD(current_page, current_page, col2, col2+(CHAR_WIDTH));
        }
        ++start_col;
    }
}

void updateDire(void)
{
   int i = MAX_SNAKE_SIZE-1;
   //struct pos aux = tail[0];
   if (STATE == UP)
   {
      tail[0].x -= 1;
   }
   if (STATE == DOWN)
   {
      tail[0].x += 1;
   }
   if (STATE == LEFT)
   {
      tail[0].y -= 1;
   }
   if (STATE == RIGHT)
   {
      tail[0].y += 1;
   }
   SetDot(tail[0].x, tail[0].y);
   
   while (i > 0)
   {
      tail[i] = tail[i-1];
      //tail[i].y = tail[i-1].y;
      //tail[i].x = tail[i-1].x;
      SetDot(tail[i-1].x, tail[i-1].y);
      --i;
   }
   ClearDot(tail[MAX_SNAKE_SIZE-1].x, tail[MAX_SNAKE_SIZE-1].y);
   
}

void printCoordinates(void)
{   
    char _y[5];
    char _x[5];

    /*Format y_coordinate for output*/
    if (y_coordinate >= 100) sprintf(_y, "%d", y_coordinate);
    else 
    {
        if (y_coordinate >= 10) sprintf(_y, "%d " , y_coordinate);
        else                    sprintf(_y, "%d  ", y_coordinate);
    }

    /*Format x_coordinate for output*/
    if (x_coordinate < 10)  sprintf(_x, "%d ", x_coordinate);
    else                    sprintf(_x, "%d", x_coordinate);

    writeTxt(0, 22, _x);
    writeTxt(1, 22, _y);    
}

void main(void)
{
    configPIC();            //setup PIC18 PORTS
    GLCDinit();		        //Initialize GLCD
    clearGLCD(0,7,0,127);   //Clear screen
    setStartLine(0);        //Set start line
    //present(nom1, 5, 6);
    //present(nom2, 3, 6);
    //present(LAB3, 1, 7);

    //__delay_ms(1000);

    //clearGLCD(1,5,25,90);   //Clear screen

    bool pressed, can_move, can_go_down;
    pressed     = false;    //boolean to implement button_up rising edge
    can_move    = true;     //boolean to implement button_up rising edge
    can_go_down = false;    //boolean to implement button_down falling edge
   
   struct pos MANZANA = {-1,-1};
   bool EXISTE_COMIDA = false;

    putchGLCD(0, 20, 'x');
    putchGLCD(0, 21, '=');
    putchGLCD(1, 20, 'y');
    putchGLCD(1, 21, '=');
    
    tail[0].x = 31; tail[0].y = 63;
    tail[1].x = 32; tail[1].y = 63;
    tail[2].x = 33; tail[2].y = 63;
    tail[3].x = 34; tail[3].y = 63;
    tail[4].x = 35; tail[4].y = 63;
    tail[5].x = 36; tail[5].y = 63;
    tail[6].x = 37; tail[6].y = 63;
    tail[7].x = 38; tail[7].y = 63;
    tail[8].x = 39; tail[8].y = 63;
    tail[9].x = 40; tail[9].y = 63;
    

    /*MAIN LOOP*/
    while (true)
    {   
        ClearDot(x_coordinate, y_coordinate);
        /*Top button*/
        if (PORTAbits.RA0 && !pressed) pressed = true;
        else if (pressed && can_move) 
        {
	   STATE = UP;
           can_move = false;
        }
        else if (!PORTAbits.RA0) {pressed = false; can_move = true;}

        /*Bottom button*/
        if (PORTAbits.RA1) can_go_down = true;
        else if (!PORTAbits.RA1 && can_go_down)
        {
	   STATE = DOWN;
	   can_go_down = false;
        }

        /*Left Button*/
        if (PORTAbits.RA3) 
        {
	   STATE = LEFT;
        }

        /*Right Button*/
        if (PORTAbits.RA2) 
        {
	   STATE = RIGHT;
        }
	
	updateDire();
	if ((MANZANA.x == tail[0].x) && (MANZANA.y == tail[0].y))
	{
	   EXISTE_COMIDA = false;
	}
	++contador;
	__delay_ms(250);
	
	if ((contador > 5) && (!EXISTE_COMIDA))
	{	
	   bool overlap = false;
	   byte it = 0;
	   MANZANA.x = rand()%63;
	   MANZANA.y = rand()%127;
	   EXISTE_COMIDA = true;
	   while (it < MAX_SNAKE_SIZE && !overlap)
	   {
	      if ((MANZANA.x == tail[it].x) && (MANZANA.y == tail[it].y)) overlap = true;
	      ++it;
	   }
	   if (!overlap ) SetDot(MANZANA.x, MANZANA.y);
	  
	}

	
        //SetDot(x_coordinate, y_coordinate);
        //printCoordinates();
    }
}