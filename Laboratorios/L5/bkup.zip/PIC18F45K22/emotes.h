#ifndef EMOTES_H
#define EMOTES_H
// Llista de caracters especials disponiblas
// Fer servir els noms definits als defines per mes llegibilitat

#define COR 0

#define FIXED_SIZE 1 //amount of emotes


unsigned const char emote_list[FIXED_SIZE * 5] =
{
	0x0C, 0x1E, 0x3C, 0x1E, 0x0C //Heart
};

#endif