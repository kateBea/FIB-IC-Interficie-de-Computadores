/* 
 * Created:   2022
 * Processor: PIC18F45K22
 * Compiler:  MPLAB XC8
 */

#include <xc.h>
#include <string.h>
#include "config.h"
#include "GLCD.h"
#include "emotes.h"

#define _XTAL_FREQ 8000000  
#define TMR0_MSB 0xF4
#define TMR0_LSB 0x24

int progress = 0;
int aux_prog = 0;

void interrupt timer0(void)
{
    if (INTCONbits.TMR0IE && INTCONbits.TMR0IF)
    {
        INTCONbits.TMR0IF = 0;
        aux_prog = progress;
        progress = rand() % 100;
        TMR0L = 0x00 - TMR0_LSB;
        TMR0H = 0x00 - TMR0_MSB;
        
        if (aux_prog > progress) for (int i = aux_prog; i > progress; --i) writeByte(0, i, 0x00);
        if (aux_prog < progress) for (int i = aux_prog; i <= progress; ++i) writeByte(0, i, 0xFF);

        if (aux_prog < 50 && progress > 50) writeEmoteInverted(0, 24, COR);
        if (aux_prog > 50 && progress < 50)
        {
            char idx_y = 24 * 5;
            writeByte(0, idx_y - 1, 0x00);
            writeByte(0, idx_y + 5, 0x00);
            writeEmote(0, 24, COR);
        }
        writeNum(0, 21, progress);
    }
}

/*Setup timer 0*/
void setupTMR0(void)
{
    T0CONbits.TMR0ON = 1; 	// Enables Timer0
    T0CONbits.T08BIT = 0; 	// Configure Timer0 as a 16-bits timer
    T0CONbits.T0CS = 0;   	// Instruction cycle clock
    T0CONbits.PSA = 0;	 	// Prescaler is assigned
    T0CONbits.T0PS = 0b100;	// Timer0 prescaler select bits
    INTCONbits.GIE = 1;		// Enable Global interrupts
    INTCONbits.TMR0IF = 0;
}

void main(void)
{
    ANSELA = 0x00; 
    ANSELB = 0x00;                  
    ANSELC = 0x00;                  
    ANSELD = 0x00;
    ANSELE = 0x00;   
   
    TRISD = 0x00;		   
    TRISB = 0x00;
    
    PORTD = 0x00;
    PORTB = 0x00;  
   
    GLCDinit();		        //Inicialitzem la pantalla
    clearGLCD(0,7,0,127);   //Esborrem pantalla
    setStartLine(0);        //Definim linia d'inici
    setupTMR0();
   
    writeEmote(0, 24, COR);
    writeNum(0, 21, progress);

    INTCONbits.TMR0IE = 1;
    while (1);
}
